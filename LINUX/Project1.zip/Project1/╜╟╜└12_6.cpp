#include <stdio.h>
#include <math.h>
#define PI  3.141592
int main(void)
{
   double theta=-PI/3;
   printf("sin=%f  cos=%f  tan=%f\n", sin(theta), 
                      cos(theta), tan(theta));
   return 0;
}



