#include  <stdio.h>
void main()
{
   float a=5.3, b=7.6, c;
   c=2*a*a-4*a*b;
   printf("c=%f\n", c);
}
