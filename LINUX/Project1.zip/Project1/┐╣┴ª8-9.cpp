#include <stdio.h>
void main()
{
  for(int i=1;i<=5;i+=1)
  {
     printf("%d) �̸� : ȫ�浿\n", i);
     printf("-----------------\n");
  }
}
