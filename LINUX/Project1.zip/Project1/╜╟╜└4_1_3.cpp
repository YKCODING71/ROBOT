#include  <stdio.h>
void main()
{
   int a=5, b=7, c;
   c=2*a+4*b;
   printf("c=%d\n", c);
}
