#include <stdio.h>
void main()
{
   for(int i=1;i<=3;i+=1)
      printf("AAA\n");
}
