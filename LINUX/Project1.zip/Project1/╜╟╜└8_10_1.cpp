#include <stdio.h>
void main()
{
 int i=11;
 do
 { 
   printf("%d ", i);
   i+=2; 
 }while(i<30);
}



