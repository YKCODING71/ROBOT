#include <stdio.h>
void main()
{
 int i=30;
 while(i>=10)
 { 
   printf("%d ", i);
   i-=2; 
 }
}


