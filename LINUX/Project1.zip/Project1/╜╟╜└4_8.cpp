#include <stdio.h>
void main()
{ 
  double a=5., b=7., c;
  c=a*b-5;
  printf("%6.2f\n", c);
  c=a/2.+b;
  printf("%6.2f\n", c);
  c=2*a+4*b;
  printf("%6.2f\n", c);
}

