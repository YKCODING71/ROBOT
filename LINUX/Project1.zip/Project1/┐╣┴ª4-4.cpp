#include <stdio.h>
void main()
{
   int a, b, c; 
   a=10;
   b=15;
   c=a*b;
   printf("%d\n",c);
}
