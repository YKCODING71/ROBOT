#include <stdio.h>
void main()
{
   double x=3.5, y=7.9;
   printf("%.2f\n", x+y);
   printf("%.2f\n", x-y);
   printf("%.2f\n", x*y);
   printf("%.2f\n", x/y);
}
