#include <stdio.h>
int main(void)
{
   char name[]={'A', 'h', 'n',' ','K', 'i', 's', 'o', 'o'};
   for(int i=0;i<9;i+=1)
     printf("%c", name[i]);
  return 0;
}

