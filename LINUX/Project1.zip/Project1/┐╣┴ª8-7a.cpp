#include <stdio.h>
void main()
{
 for(int i=1;i<=10;i+=1)
   printf("%d ", i);
}
