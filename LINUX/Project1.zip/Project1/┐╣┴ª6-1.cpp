#include <stdio.h>
void main()
{
 double x=2.5, y=5.0;
 printf("\n x+y= %7.2f", x+y);
 printf("\n x-y= %7.2f", x-y);
 printf("\n x*y= %7.2f", x*y);
 printf("\n x/y= %7.2f", x/y);
}
