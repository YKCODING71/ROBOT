#include <stdio.h>
void main()
{
 int i=30;
 do
 { 
   printf("%d ", i);
   i-=2; 
 }while(i>=10);
}



