#include <stdio.h>
void main()
{ 
 int i;
 for(i=1;i<=9;i=i+1)
   printf("%d * %d  = %d\n", 1, i, 1*i);  
}                   
