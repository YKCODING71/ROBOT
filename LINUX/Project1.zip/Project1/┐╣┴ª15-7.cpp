#include <stdio.h>
struct user
  {
   char name[20];
   char phone[14];
   int quick;
  };
int main(void)
{
 user d[2]={{"���ȯ","011-123-4567",1},
              {"������","010-120-5638",5}};
 user *pt;
 int i;
 pt=d;
 for(i=0;i<2;i++)
 {
  printf("name :%s\n", (pt+i)->name);
  printf("phone:%s\n", (pt+i)->phone);
  printf("quick:%d\n", (pt+i)->quick);
  printf("\n");
  printf("name :%s\n", d[i].name);
  printf("phone:%s\n", d[i].phone);
  printf("quick:%d\n", d[i].quick);
  printf("\n");
 }
 return 0;
}
