#include <stdio.h>
int main(void)
{
 int sum;
 for(int i=1;i<=10;i++)
    sum+=i;
 printf("1+2+3+...+10=%d\n", sum);
 return 0;
} 
