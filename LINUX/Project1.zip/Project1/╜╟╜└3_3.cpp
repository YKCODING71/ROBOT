#include  <stdio.h>
void main()
{
   printf("%.0f\n", 0.64);
   printf("%.1f\n", 0.4223);
   printf("%.2f\n", 12.6732);
   printf("%.3f\n", -6.3634);
}
