#include <stdio.h>
void main()
{
  int a=5, b=3;
  double x=2.5;
  printf("a/b=%d \n",a/b);
  printf("a%%b=%d \n",a%b);
  printf("x/b=%f \n",x/b);
}
