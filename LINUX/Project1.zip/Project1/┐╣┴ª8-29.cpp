#include <stdio.h>
void main()
{
  for(int i=4;i<=10; )
  {
     printf("i=%d\n", i);
     i+=2;
  }
}
