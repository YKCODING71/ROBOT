#include  <stdio.h>
void main()
{
   float a=5, c;
   int b=7;
   c=a/2.+b;
   printf("c=%f\n", c);
}
