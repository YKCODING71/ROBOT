#include <stdio.h>
int main(void)
{
 char nation[3][9]={"Korea","China","Thailand"};
 for(int i=0;i<3;i++)
   printf("%s\n", nation[i]);;
 return 0;
}
