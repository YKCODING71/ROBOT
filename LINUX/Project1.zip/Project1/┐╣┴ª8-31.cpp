#include <stdio.h>
void main()
{
 for(int i=0,j=2;i<=10 && j<=10;i+=2,j+=1)
   printf("i=%2d j=%2d\n", i, j);
}
