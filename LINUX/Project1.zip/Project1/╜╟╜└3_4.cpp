#include  <stdio.h>
void main()
{
   printf("%d+%d=%d\n", 9, 5, 9+5);
   printf("%d-%d=%d\n", 9, 5, 9-5);
   printf("%d*%d=%d\n", 9, 5, 9*5);
   printf("%d/%d=%d\n", 9, 5, 9/5);
}
