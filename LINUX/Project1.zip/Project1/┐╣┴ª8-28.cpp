#include <stdio.h>
void main()
{
  int i=4;
  for( ;i<=10;i+=2 )
   printf("i=%d\n", i);
}
