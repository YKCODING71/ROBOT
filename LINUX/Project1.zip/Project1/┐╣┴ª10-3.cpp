#include <stdio.h>
#include <math.h>
void main()
{
  printf("%f\n",sqrt((double) 2));
  printf("%f\n",sqrt((double) 9));
}
