#include <stdio.h>
void main()
{
 int i=11;
 while(i<=30)
 { 
   printf("%d ", i);
   i+=2; 
 }
}

