#include <stdio.h>
void main()
{ 
  int a, b;
  a=b=2;
  a+=b;
  b*=a;
  printf(" a= %d, b = %d \n", a, b);
}
