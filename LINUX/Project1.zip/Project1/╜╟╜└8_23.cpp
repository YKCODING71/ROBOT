#include <stdio.h>
void main()
{
 for(int i=10,j=10;i>=1 && j<=20;i-=1,j+=2)
   printf("i=%2d j=%2d\n", i, j);
}

