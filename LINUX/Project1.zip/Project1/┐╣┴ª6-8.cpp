#include <stdio.h>
void main()
{
  int a=4, b=8;	
  (a>b) ? printf("a>b") : printf("a<=b");
}
