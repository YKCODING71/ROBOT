#include  <stdio.h>
void main()
{
   printf("���� : %s\n", "C program");
}

