#include <stdio.h>
void main()
{ 
  unsigned char a=16, b=32;
  printf("a<<1 = %d\n", a<<1);
  printf("b>>1 = %d\n", b>>1);
}
