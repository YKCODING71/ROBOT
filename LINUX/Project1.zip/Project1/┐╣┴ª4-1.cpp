#include <stdio.h>
void main()
{
  printf("%s  %d\n", "�伺",   1426980000);
  printf("%s  %d\n", "õ�ռ�", 2870000000);
  printf("%s  %d\n", "�ؿռ�", 4497070000);
  printf("%s  %d\n", "���ռ�", 5913520000);
}
