#include <stdio.h>
void main()
{
   int a=3, b=5;
   a=a+b;
   b=b+a;
   printf("%d\n", a);
   printf("%d\n", b);
}
