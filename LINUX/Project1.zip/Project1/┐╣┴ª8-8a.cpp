#include <stdio.h>
void main()
{
 for(double i=0;i<=0.5;i+=0.1)
   printf("%.1f\n", i);
}
