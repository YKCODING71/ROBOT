﻿#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
void main()
{
 int a, b;
 printf("10진정수를 입력하고 Enter>");
 scanf("%d", &a);
 printf("10진정수를 입력하고 Enter>");
 scanf("%d", &b);
 printf("a+b=%d \n", a+b);
 printf("a-b=%d \n", a-b);
 printf("a*b=%d \n", a*b);
 printf("a/b=%d \n", a/b);  //정수 나누기 정수의 결과가 정수로 나타나는 문제발생 
}


