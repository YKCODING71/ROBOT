#include <stdio.h>
void main()
{
   int a=10, b=15, c; 
   c=a*b;
   printf("%d\n",c);
}
