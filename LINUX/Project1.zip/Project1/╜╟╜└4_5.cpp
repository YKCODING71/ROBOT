#include  <stdio.h>
void main()
{
   int a=3, b=5;
   int c, d;
   a=a+b;
   b=a-b;
   a=a-b;
   printf("a=%d\n",a);
   printf("b=%d\n",b);
}
