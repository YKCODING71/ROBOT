#include <stdio.h>
int main(void)
{
 char str[20]="program";
 puts("C ���");
 puts(str);
 return 0;
}
