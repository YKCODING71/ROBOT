#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
void main()
{
 int a, b;
 scanf("%d", &a);
 scanf("%d", &b);
 printf("a+b=%d \n", a+b);
}
