#include <stdio.h>
#include <math.h>
void main()
{
  printf("pow(10,3)=%.3f\n",pow(10., 3.));
  printf("pow(2, 4)=%.3f\n", pow(2.,4.));
}
