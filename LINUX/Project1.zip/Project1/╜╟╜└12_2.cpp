#include <stdio.h>
#include <stdlib.h>
int main(void)
{
	printf("%f\n", atoi("1234") + atof("0.5678"));
	return 0;
}

