#include  <stdio.h>
void main()
{
  printf("Ű�� 175.3 cm\n");
}
