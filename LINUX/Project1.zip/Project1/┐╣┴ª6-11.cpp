#include <stdio.h>
void main()
{
 printf("int size : %d\n", sizeof(int));
 printf("double size : %d\n", sizeof(double));
 printf("(3+5.2) size :%d\n", sizeof(3+5.2));
}
