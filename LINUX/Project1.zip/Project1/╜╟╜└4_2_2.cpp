#include  <stdio.h>
void main()
{
   float a=5.3, b=7.6, c;
   c=(a-b)/(a+b);
   printf("c=%f\n", c);
}
