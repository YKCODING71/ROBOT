#include <stdio.h>
void main()
{
   for(int j=1;j<=3;j+=1)
      printf("A");
}
