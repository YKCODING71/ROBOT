#include <stdio.h>
void main()	
{
 int a=10, b=20;
 printf("a=%d\n", a++);
 printf("a=%d\n", ++a);
 printf("b=%d\n", b--);
 printf("a=%d\n", --b);
}
