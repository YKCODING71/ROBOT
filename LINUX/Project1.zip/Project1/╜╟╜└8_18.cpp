#include <stdio.h>
void main()
{
   for(int i=1;i<=3;i+=1)
   {
  	for(int j=1;j<=3;j+=1)
              printf("%d %d", i, j);
   	printf("\n");
   }
}
