#include <stdio.h>
void main()
{
  int a, b, c;
  a=3;
  b=5;
  c=a;  
  a=b;  
  b=c;  
  printf("a=%d\n", a);
  printf("b=%d\n", b);
}

