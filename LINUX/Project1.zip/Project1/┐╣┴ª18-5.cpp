#include<stdio.h>
#define SQUARE(x) x*x
int main(void)
{
 printf("SQUARE(5)=%d\n", SQUARE(5));
 return 0;
}
