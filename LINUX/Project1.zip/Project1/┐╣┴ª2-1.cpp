#include  <stdio.h>
void main()
{
    printf("C��� programming");
}
