#include <stdio.h>
int sum(int a, int b);
void main()
{
	int a1 = 5, a2 = 8;
	printf("a+b=%d\n",sum(a1, a2));
}

int sum(int a, int b)
{
	return a + b;
}


