#include <stdio.h>
void main()
{
   double x=3.5, y=7.9;
   printf("%.1f+%.1f=%6.2f\n", x, y, x+y);
   printf("%.1f-%.1f=%6.2f\n", x, y, x-y);
   printf("%.1f*%.1f=%6.2f\n", x, y, x*y);
   printf("%.1f/%.1f=%6.2f\n", x, y, x/y);
}
