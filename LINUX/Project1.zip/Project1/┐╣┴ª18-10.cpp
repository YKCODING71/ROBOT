#if LEVEL == 1
#include"novice.h"
#elif LEVEL == 2
#include"middle.h"
#elif LEVEL == 3
#include"expert.h"
#else
#include"general.h"
#endif
