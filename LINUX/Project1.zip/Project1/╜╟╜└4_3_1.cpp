#include  <stdio.h>
void main()
{
   int a, b;
   a=3;
   b=5;
   a=a+b;
   b=b+a;
   printf("a=%d\n",a);
   printf("b=%d\n",b);
}
