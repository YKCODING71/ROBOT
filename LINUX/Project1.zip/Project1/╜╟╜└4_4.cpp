#include  <stdio.h>
void main()
{
   int a=3, b=5;
   int c, d;
   c=a+b;
   d=a-b;
   d=c;
   c=a-b;
   printf("a=%d\n",c);
   printf("b=%d\n",d);
}
